import javax.servlet.*;
import java.io.*;
public class DpServlet1 extends GenericServlet
{
 public void service(ServletRequest req,ServletResponse res) throws ServletException,IOException 
 {
   
   res.setContentType("text/html");
   PrintWriter pw=res.getWriter();
   pw.println("<b>WELCOME TO SERVLETS</b>");
 }
}
